def binary_search(A, l, h, k):
    if h >= l:
        mid = int(l + (h - l)/2)
        print(mid)
        if A[mid] == k:
            return 'k is found'
        elif A[mid] > k:
            return binary_search(A, l, mid-1, k)
        else:
            return binary_search(A, mid+1, h, k)
    else:
        return 'k is not found'

A=[1,2,3,4,5,8]
k=5;l=0; h=len(A)-1;
binary_search(A, l, h, k)
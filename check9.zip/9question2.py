def power(a,b):
    d=a**b
    return d
print(power(11,2))